This folder contains all the code files made using the Smolagents Framework
