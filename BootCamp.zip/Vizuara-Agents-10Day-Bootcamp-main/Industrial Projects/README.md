A list of industrial AI Agents Projects
