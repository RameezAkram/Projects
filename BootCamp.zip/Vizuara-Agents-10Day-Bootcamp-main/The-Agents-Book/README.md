This is a collection of all the Substack posts regarding the bootcamp, compiled into a book format. 

Here is where you can find and download the book: https://drive.google.com/file/d/1-hEM5ed-650L-21rRY6oV0B-VrPcWu3J/view?usp=sharing
