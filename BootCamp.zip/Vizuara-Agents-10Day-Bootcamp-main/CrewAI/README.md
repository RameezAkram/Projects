This folder contains all code files made using CrewAI framework
